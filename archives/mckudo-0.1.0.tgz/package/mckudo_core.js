// MCKudo Core — created by y9kudo. Public library entry point.
export { MckudoCore, createCore } from './src/core.js';
export { validateConfig, ConfigError } from './src/config.js';
export { matches } from './src/conditions.js';
export { MCKUDO } from './src/identity.js';
