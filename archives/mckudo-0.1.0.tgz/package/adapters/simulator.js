import { jsonCopy } from '../src/config.js';
// A deterministic, offline example. It never connects to Minecraft.
export function createSimulator(initial = {}) {
  const world = { dimension: 'minecraft:overworld', self: { health: 20, food: 12, position: { x: 0, y: 64, z: 0 } }, inventory: { 'minecraft:oak_log': 0, 'minecraft:bread': 3 }, ...jsonCopy(initial) };
  return {
    describe: () => ({ protocolVersion: 1, kind: 'simulator', loader: 'vanilla', minecraftVersion: 'simulation', skills: ['eat', 'gather'] }),
    observe: async ({ signal }) => { signal.throwIfAborted(); return jsonCopy(world); },
    execute: async ({ skill, args }, { signal }) => {
      signal.throwIfAborted();
      if (skill === 'eat') {
        if (world.inventory['minecraft:bread'] < 1) throw new Error('Нет хлеба.');
        world.inventory['minecraft:bread']--; world.self.food = Math.min(20, world.self.food + 5);
      } else if (skill === 'gather') {
        if (typeof args.block !== 'string' || !Number.isInteger(args.count) || args.count < 1 || args.count > 16) throw new Error('Укажи block и count от 1 до 16.');
        world.inventory[args.block] = (world.inventory[args.block] || 0) + args.count;
      } else throw new Error('Нет такого навыка в симуляторе.');
      return { ok: true };
    },
  };
}
