import { EventEmitter } from 'node:events';
import { validateConfig, jsonCopy, id, object } from './config.js';
import { matches } from './conditions.js';
import { MCKUDO } from './identity.js';

export class MckudoCore extends EventEmitter {
  #config; #adapter; #skills = new Map(); #clock; #pending = null; #abort; #timer; #loop = false; #paused = false;
  #cooldowns = new Map(); #stats = Object.create(null); #history = []; #state; #generation = 0;
  constructor({ config, adapter, memory, clock = Date.now }) {
    super();
    this.#config = validateConfig(config);
    if (!adapter || typeof adapter.observe !== 'function' || typeof adapter.execute !== 'function' || typeof adapter.describe !== 'function') throw new TypeError('Адаптер должен реализовать describe(), observe() и execute().');
    this.#adapter = adapter; this.#clock = clock;
    const manifest = jsonCopy(adapter.describe());
    if (manifest.protocolVersion !== 1 || !Array.isArray(manifest.skills) || !manifest.skills.every(id)) throw new TypeError('Адаптер: нужен protocolVersion: 1 и список skills.');
    this.manifest = Object.freeze({ ...manifest, skills: Object.freeze([...manifest.skills]) });
    if (memory !== undefined) this.#restore(memory);
    this.#state = { engine: MCKUDO, name: this.#config.name, worldId: this.#config.worldId, status: 'idle', reason: 'Ожидание первого наблюдения.', decision: null, observation: null, adapter: manifest, lastResult: null };
  }
  #restore(input) {
    const m = jsonCopy(input);
    if (m.schemaVersion !== 1 || m.worldId !== this.#config.worldId || !object(m.stats) || !Array.isArray(m.history)) throw new TypeError('Память другого мира или неподдерживаемого формата.');
    for (const r of this.#config.rules) {
      const s = Object.hasOwn(m.stats, r.id) ? m.stats[r.id] : null;
      if (s) {
        if (!['successes', 'failures', 'streak'].every(k => Number.isSafeInteger(s[k]) && s[k] >= 0)) throw new TypeError('Повреждены счётчики памяти.');
        this.#stats[r.id] = { successes: s.successes, failures: s.failures, streak: s.streak };
      }
    }
    this.#history = m.history.slice(-this.#config.maxHistory);
  }
  registerSkill(name, handler) {
    if (!id(name) || typeof handler !== 'function') throw new TypeError('Навыку нужны имя и функция.');
    if (this.#skills.has(name) || this.manifest.skills.includes(name)) throw new Error(`Навык уже зарегистрирован: ${name}`);
    this.#skills.set(name, handler); return this;
  }
  snapshot() { return jsonCopy({ ...this.#state, paused: this.#paused, running: this.#loop, history: this.#history }); }
  exportMemory() { return jsonCopy({ schemaVersion: 1, worldId: this.#config.worldId, stats: this.#stats, history: this.#history }); }
  #notify() { this.emit('state', this.snapshot()); }
  #context(o) {
    const p = o.self?.position;
    return p && Number.isFinite(p.x) && Number.isFinite(p.z) ? `${o.dimension || 'world'}:${Math.floor(p.x / 8)}:${Math.floor(p.z / 8)}` : 'world';
  }
  tick() {
    if (this.#pending) return this.#pending;
    if (this.#paused) return Promise.resolve(this.snapshot());
    // Defer execution until the lock exists, including events emitted synchronously by adapters.
    this.#pending = Promise.resolve().then(() => this.#step()).finally(() => { this.#pending = null; });
    return this.#pending;
  }
  async #step() {
    if (this.#paused) return this.snapshot();
    const ac = new AbortController(); this.#abort = ac;
    let timedOut = false, plan = null, context = 'world';
    const timeout = setTimeout(() => { timedOut = true; ac.abort(new Error('Истекло время задачи.')); }, this.#config.actionTimeoutMs);
    try {
      this.#state.status = 'observing'; this.#state.decision = null;
      const o = jsonCopy(await this.#adapter.observe({ signal: ac.signal })); ac.signal.throwIfAborted();
      this.#state.observation = o; context = this.#context(o);
      const now = this.#clock();
      for (const [key, until] of this.#cooldowns) if (until <= now) this.#cooldowns.delete(key);
      const applicable = this.#config.rules.filter(r => matches(r.when, o)).sort((a, b) => b.priority - a.priority);
      const candidates = applicable.map(r => ({ ...r, blocked: !this.#skills.has(r.action.skill) && !this.manifest.skills.includes(r.action.skill) ? 'Адаптер не поддерживает навык.' : this.#cooldowns.has(context + '/' + r.id) ? 'Пауза после ошибки в этой области.' : null }));
      plan = candidates.find(r => !r.blocked);
      if (!plan) {
        this.#state.status = candidates.length ? 'blocked' : 'idle';
        this.#state.reason = candidates[0]?.blocked || 'Нет правил, условия которых сейчас выполнены.';
        this.#notify(); return this.snapshot();
      }
      this.#state.decision = jsonCopy({ id: plan.id, action: plan.action, priority: plan.priority, alternatives: candidates.filter(r => r !== plan).map(r => ({ id: r.id, blocked: r.blocked })) });
      this.#state.status = 'acting'; this.#state.reason = plan.description || `Выполнено условие правила ${plan.id}; выбрано по приоритету ${plan.priority}.`;
      this.#notify(); this.emit('action:start', jsonCopy(this.#state.decision));
      ac.signal.throwIfAborted();
      const handler = this.#skills.get(plan.action.skill);
      const result = handler ? await handler(jsonCopy(plan.action.args), { signal: ac.signal, observation: jsonCopy(o) }) : await this.#adapter.execute(jsonCopy(plan.action), { signal: ac.signal });
      ac.signal.throwIfAborted();
      if (result?.ok === false) throw new Error(String(result.message || 'Навык сообщил о неудаче.'));
      this.#record(plan, context, 'success');
      this.#state.status = 'idle'; this.#state.reason = 'Действие завершено. Следующий шаг начнётся с нового наблюдения.';
    } catch (error) {
      const cancelled = ac.signal.aborted && !timedOut;
      const message = timedOut ? 'Истекло время задачи.' : String(error?.message || error).slice(0, 300);
      if (plan) this.#record(plan, context, cancelled ? 'cancelled' : 'failure', message);
      this.#state.status = cancelled ? 'paused' : 'fault'; this.#state.reason = message;
    } finally { clearTimeout(timeout); if (this.#abort === ac) this.#abort = null; }
    this.#notify(); return this.snapshot();
  }
  #record(plan, context, outcome, detail = '') {
    if (outcome !== 'cancelled') {
      const s = this.#stats[plan.id] ||= { successes: 0, failures: 0, streak: 0 };
      if (outcome === 'success') { s.successes++; s.streak = 0; }
      else { s.failures++; s.streak++; this.#cooldowns.set(context + '/' + plan.id, this.#clock() + Math.min(300000, this.#config.failureBackoffMs * 2 ** Math.min(s.streak - 1, 6))); }
    }
    const result = { at: this.#clock(), rule: plan.id, skill: plan.action.skill, outcome, detail };
    this.#history.push(result); this.#history = this.#history.slice(-this.#config.maxHistory);
    this.#state.lastResult = result; this.emit('action:finish', jsonCopy(result));
  }
  start() {
    if (this.#loop) { this.resume(); return this; }
    this.#loop = true; this.#paused = false; const generation = ++this.#generation;
    const next = async () => {
      if (!this.#loop || generation !== this.#generation) return;
      try { await this.tick(); } catch (e) { this.#state.status = 'fault'; this.#state.reason = String(e.message).slice(0, 300); }
      if (this.#loop && generation === this.#generation) this.#timer = setTimeout(next, this.#config.tickIntervalMs);
    };
    void next(); return this;
  }
  pause() {
    this.#paused = true; this.#abort?.abort(new Error('Действие остановлено пользователем.'));
    this.#state.status = this.#pending ? 'stopping' : 'paused'; this.#state.reason = 'Пауза запрошена.'; this.#notify();
    return this.#pending || Promise.resolve(this.snapshot());
  }
  resume() { this.#paused = false; this.#state.status = this.#pending ? 'stopping' : 'idle'; return this; }
  async stop() { this.#loop = false; this.#generation++; clearTimeout(this.#timer); await this.pause(); }
}
export const createCore = options => new MckudoCore(options);
