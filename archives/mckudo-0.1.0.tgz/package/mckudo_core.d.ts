export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export type Observation = { [key: string]: Json };
export type Condition = { all: Condition[] } | { any: Condition[] } | { not: Condition } | ({ fact: string } & (
  { eq: string | number | boolean | null } | { ne: string | number | boolean | null } |
  { lt: number } | { lte: number } | { gt: number } | { gte: number } | { exists: boolean }
));
export interface Action { skill: string; args?: Record<string, Json>; }
export interface Rule { id: string; priority?: number; description?: string; when?: Condition; action: Action; }
export interface AgentConfig { $schema?: string; schemaVersion: 1; name: string; worldId: string; rules: Rule[]; tickIntervalMs?: number; actionTimeoutMs?: number; failureBackoffMs?: number; maxHistory?: number; }
export interface Manifest { protocolVersion: 1; kind: string; loader: string; minecraftVersion: string; skills: readonly string[]; }
export interface Context { signal: AbortSignal; }
export interface Adapter { describe(): Manifest; observe(context: Context): Promise<Observation>; execute(action: Action, context: Context): Promise<unknown>; }
export interface Result { at: number; rule: string; skill: string; outcome: 'success' | 'failure' | 'cancelled'; detail: string; }
export interface Memory { schemaVersion: 1; worldId: string; stats: Record<string, { successes: number; failures: number; streak: number }>; history: Result[]; }
export interface Snapshot { engine: typeof MCKUDO; name: string; worldId: string; status: 'idle' | 'observing' | 'acting' | 'blocked' | 'fault' | 'paused' | 'stopping'; reason: string; paused: boolean; running: boolean; adapter: Manifest; observation: Observation | null; decision: { id: string; action: Action; priority: number; alternatives: { id: string; blocked: string | null }[] } | null; lastResult: Result | null; history: Result[]; }
export declare const MCKUDO: Readonly<{ name: string; id: 'mckudo_core'; version: string; author: 'y9kudo'; protocolVersion: 1 }>;
export declare class ConfigError extends Error { readonly path: string; }
export declare function validateConfig(input: unknown): AgentConfig;
export declare function matches(condition: Condition | undefined, observation: Observation): boolean;
export interface CoreOptions { config: AgentConfig; adapter: Adapter; memory?: Memory; clock?: () => number; }
export declare class MckudoCore {
  constructor(options: CoreOptions);
  readonly manifest: Manifest;
  registerSkill(name: string, handler: (args: Record<string, Json>, context: Context & { observation: Observation }) => Promise<unknown>): this;
  tick(): Promise<Snapshot>;
  start(): this;
  pause(): Promise<Snapshot>;
  resume(): this;
  stop(): Promise<void>;
  snapshot(): Snapshot;
  exportMemory(): Memory;
  on(event: 'state', listener: (snapshot: Snapshot) => void): this;
  on(event: 'action:start', listener: (decision: NonNullable<Snapshot['decision']>) => void): this;
  on(event: 'action:finish', listener: (result: Result) => void): this;
  removeAllListeners(event?: string): this;
}
export declare function createCore(options: CoreOptions): MckudoCore;
